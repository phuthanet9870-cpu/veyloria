Veyloria — แก้หน้าจอขาว / Standalone build

1. แตกไฟล์ ZIP นี้ไปโฟลเดอร์ใหม่
2. ดับเบิลคลิก index.html เพื่อเปิดเกมใน Chrome

รุ่นนี้รวม JavaScript, CSS และภาพทั้งหมดใน index.html แล้ว ไม่ต้องเปิด HTTP server
ไม่ต้องนำ assets จากรุ่นเก่ามารวม และไม่ต้องปิดการป้องกัน CORS ของ browser
เกมเล่นคนเดียวได้ ออฟไลน์ได้ การเซฟขึ้นกับ browser storage
ระบบออนไลน์ยังต้องใช้ backend แยก
