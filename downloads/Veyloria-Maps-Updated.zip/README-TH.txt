เกม Veyloria รุ่นภาพแผนที่ใหม่ครบ 136 แมพ / 21 ธีม
แตก ZIP แล้วนำไฟล์ทั้งหมดขึ้น static web hosting หรือเปิดผ่าน HTTP server ในโฟลเดอร์นี้ เช่น python -m http.server 8000
ไม่แนะนำเปิด index.html ด้วย file:// เพราะ browser จำกัดการโหลด JavaScript modules
เกมเล่นคนเดียวได้ ส่วนออนไลน์ต้องเปิด backend จากชุดซอร์สแยก
