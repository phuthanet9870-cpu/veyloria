ชุดภาพแผนที่ Veyloria
มี tileset 21 ธีม และ sheet วัตถุ 21 ธีม พร้อมต้นฉบับ 3 atlas
Tileset: ขนาด 256x2560 แบ่งเป็น 10 แถบวัสดุ แต่ละแถบสูง 256 พิกเซล มี tile 32x32 จำนวน 64 แบบ (8x8)
วัสดุตามลำดับ: grass, grass_dark, forest_floor, dirt, soil, path_stone, ruin_floor, sand, water, thorn_ground
ตำแหน่ง frame ในเกมใช้ x=worldTileX%8 และ y=worldTileY%8 ห้ามสุ่มสลับ frame โดยไม่มีระบบต่อขอบ
Prop sheets: 768x512 ตาราง 6x4 ช่องละ 128 พิกเซล เรียงตาม src/data/objects.json ช่อง glint ว่างเพราะเป็นแสง procedural
ภาพที่ส่งมีกรอบโปร่งใสเพื่อไม่ตัดปลายวัตถุ เกมสร้างขนาด/ภาพกลับด้าน 8 รูปแบบอย่างคงที่
แผนที่ทั้ง 136 ใช้ภาพผ่าน manifest ใน src/game/art/environmentManifest.ts
