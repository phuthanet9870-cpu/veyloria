Veyloria Environment Art
21 themed tilesets + 21 normalized prop sheets.
Terrain sheets: 256x2560, ten 256px-high material bands, each with 64 connected 32px tiles (8x8).
Rows: grass,grass_dark,forest_floor,dirt,soil,path_stone,ruin_floor,sand,water,thorn_ground.
Frame positions in game are world-aligned: tile x=worldTileX%8, tile y=worldTileY%8. Do not randomly shuffle connected frames.
Prop sheets: 768x512, 6 columns x 4 rows of 128px cells, data/objects.json order. Glint remains procedural and its cell is empty.
The runtime generates eight size/mirroring prop variants per kind. Original generated PNG masters are included in the source repository.
